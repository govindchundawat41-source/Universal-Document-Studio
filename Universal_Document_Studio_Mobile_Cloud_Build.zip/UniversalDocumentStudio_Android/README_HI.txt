UNIVERSAL DOCUMENT STUDIO — ANDROID PROJECT (V10)

यह Android Studio project आपके V10 HTML editor को offline Android app shell में चलाता है।

निर्माण:
1. Android Studio में यह पूरा project folder खोलें।
2. Gradle sync पूरा होने दें (पहली बार Android Gradle Plugin डाउनलोड करने के लिए इंटरनेट चाहिए)।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
4. APK: app/build/outputs/apk/debug/app-debug.apk

फोन में:
- APK को फोन में भेजें और install करें।
- Android सेटिंग में इस स्रोत से Install unknown apps की अनुमति देनी पड़ सकती है।
- ऐप के भीतर दस्तावेज़ localStorage में उसी ऐप के निजी डेटा क्षेत्र में रहते हैं।
- फोन बदलने/ऐप हटाने से पहले Backup बनाकर सुरक्षित रखें।
- ऐप का editor और सेव किए हुए दस्तावेज़ ऑफलाइन चलते हैं। पहली बार Gradle build के लिए कंप्यूटर पर इंटरनेट आवश्यक है।

ध्यान दें:
- यह प्रोजेक्ट Android Studio से APK बनाने के लिए है; इस पैकेज में पहले से compiled APK शामिल नहीं है।
- Android SDK/Gradle build environment उपलब्ध न होने के कारण इस वातावरण में APK compile नहीं किया जा सका।
- Android native file picker, export/save dialog और A4 print framework जोड़े गए हैं।
- वर्तमान HTML के सभी V10 editor फीचर शामिल हैं; device-specific runtime testing आवश्यक है।
