package com.universaldocumentstudio.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import android.util.Base64;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_REQUEST = 4101;
    private static final int SAVE_REQUEST = 4102;
    private String pendingName = "Universal_Document_Studio_Backup.json";
    private String pendingMime = "application/octet-stream";
    private byte[] pendingBytes;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setDefaultTextEncodingName("UTF-8");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_REQUEST); }
                catch (Exception e) { fileCallback = null; Toast.makeText(MainActivity.this, "फ़ाइल चयन उपलब्ध नहीं", Toast.LENGTH_SHORT).show(); return false; }
                return true;
            }
        });
        webView.addJavascriptInterface(new AppBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AppBridge {
        @JavascriptInterface public void saveFile(String name, String mime, String base64) {
            runOnUiThread(() -> {
                try {
                    pendingName = name == null ? "document.txt" : name.replaceAll("[\\\\/:*?\"<>|]", "_");
                    pendingMime = mime == null ? "application/octet-stream" : mime;
                    pendingBytes = Base64.decode(base64, Base64.DEFAULT);
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType(pendingMime);
                    i.putExtra(Intent.EXTRA_TITLE, pendingName);
                    startActivityForResult(i, SAVE_REQUEST);
                } catch (Exception e) { Toast.makeText(MainActivity.this, "फ़ाइल सेव नहीं हो सकी", Toast.LENGTH_LONG).show(); }
            });
        }
        @JavascriptInterface public void printDocument() {
            runOnUiThread(() -> {
                try {
                    PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                    PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("Universal Document Studio");
                    pm.print("Universal Document Studio", adapter, new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                        .setResolution(new android.print.PrintAttributes.Resolution("pdf", "PDF", 300, 300))
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
                } catch (Exception e) { Toast.makeText(MainActivity.this, "प्रिंट शुरू नहीं हो सका", Toast.LENGTH_LONG).show(); }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_REQUEST) {
            if (fileCallback != null) {
                Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
                fileCallback.onReceiveValue(result); fileCallback = null;
            }
        } else if (requestCode == SAVE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                if (out != null && pendingBytes != null) out.write(pendingBytes);
                Toast.makeText(this, "फ़ाइल सेव हो गई", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "फ़ाइल सेव करने में त्रुटि", Toast.LENGTH_LONG).show(); }
            pendingBytes = null;
        }
    }

    @Override public void onBackPressed() {
        new AlertDialog.Builder(this)
            .setMessage("ऐप बंद करना चाहते हैं?")
            .setNegativeButton("रद्द करें", (d,w) -> d.dismiss())
            .setPositiveButton("बंद करें", (d,w) -> finish())
            .show();
    }
}
